import pytest

from fixtures import docker_cli, image, run_user