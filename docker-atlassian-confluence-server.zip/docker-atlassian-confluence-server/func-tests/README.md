
# Test data

The database dump and `confluence.cfg.xml.tmpl` are dumped from a 6.0.1
instance.
